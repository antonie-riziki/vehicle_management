from django.contrib import admin
from vehicle.models import Customer, Mechanic, Request, Attendance, Feedback, FuelConsumption

# Register your models here.
admin.site.register(Customer)
admin.site.register(Mechanic)
admin.site.register(Request)
admin.site.register(Attendance)
admin.site.register(Feedback)
admin.site.register(FuelConsumption)
