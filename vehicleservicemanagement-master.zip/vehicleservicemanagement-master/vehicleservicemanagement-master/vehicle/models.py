from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Customer(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/CustomerProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_instance(self):
        return self
    def __str__(self):
        return self.user.first_name

class Mechanic(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/MechanicProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=False)
    skill = models.CharField(max_length=500,null=True)
    salary=models.PositiveIntegerField(null=True)
    status=models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return self.user.first_name


class Request(models.Model):
    cat=(('sedan','sedan'), ('SUV','SUV'), ('Van','Van'), ('Truck','Truck'), ('Pickup','Pickup'), ('Minivan','Minivan'), ('Off-Road','Off-Road'), ('Hatchback','Hatchback'), ('Coupe','Coupe'), ('Convertible','Convertible'), ('Hybrid','Hybrid'), ('Electric','Electric'), ('Sports Car','Sports Car'), ('Commercial','Commercial'), ('Luxury','Luxury'), ('Crossover','Crossover'), ('Wagon','Wagon'))
    category=models.CharField(max_length=50,choices=cat)

    vehicle_no=models.CharField(max_length=7, null=False)

    v_name=(('Toyota Camry', 'Toyota Camry'), ('Honda Civic', 'Honda Civic'), ('Nissan Altima', 'Nissan Altima'), ('Chevrolet Malibu', 'Chevrolet Malibu'), ('Ford Mustang', 'Ford Mustang'), ('Dodge Challenger', 'Dodge Challenger'), ('BMW 3 Series', 'BMW 3 Series'), ('Audi A4', 'Audi A4'), ('Mercedes-Benz C-Class', 'Mercedes-Benz C-Class'), ('Lexus ES', 'Lexus ES'), ('Tesla Model S', 'Tesla Model S'), ('Porsche 911', 'Porsche 911'), ('Ferrari 488 GTB', 'Ferrari 488 GTB'), ('Lamborghini Aventador', 'Lamborghini Aventador'))
    vehicle_name = models.CharField(max_length=40,null=False, choices=v_name)
    vehicle_model = models.CharField(max_length=40,null=False)

    v_brand=(('Toyota', 'Toyota'), ('Ford', 'Ford'),('Chevrolet', 'Chevrolet'), ('Honda', 'Honda'),('Nissan', 'Nissan'),('Mercedes-Benz', 'Mercedes-Benz'),('BMW', 'BMW'),('Audi', 'Audi'),('Volkswagen', 'Volkswagen'),('Tesla', 'Tesla'),('Jeep', 'Jeep'),('Lexus', 'Lexus'),('Subaru', 'Subaru'),('Mazda', 'Mazda'), ('Hyundai', 'Hyundai'))
    vehicle_brand = models.CharField(max_length=40,null=False, choices=v_brand)

    prob_desc=(('Engine Failure', 'Engine Failure'), ('Battery failure', 'Battery failure'), ('Transmission problems', 'Transmission problems'), ('Brake failure', 'Brake failure'), ('Electrical issues', 'Electrical issues'), ('Starter problems', 'Starter problems'), ('Fuel system problems', 'Fuel system problems'), ('Suspension problems', 'Suspension problems'), ('Overheating', 'Overheating'), ('Exhaust system problems', 'Exhaust system problems'), ('Steering problems', 'Steering problems'), ('Air conditioning problems', 'Air conditioning problems'), ('Body rust and corrosion', 'Body rust and corrosion'), ('Oil leaks', 'Oil leaks'), ('Ignition coil failure', 'Ignition coil failure'))
    problem_description = models.CharField(max_length=500,null=False, choices=prob_desc)

    date=models.DateField(auto_now=True)
    cost=models.PositiveIntegerField(null=True)

    customer=models.ForeignKey('Customer', on_delete=models.CASCADE,null=True)
    mechanic=models.ForeignKey('Mechanic',on_delete=models.CASCADE,null=True)

    stat=(('Pending','Pending'),('Approved','Approved'),('Repairing','Repairing'),('Repairing Done','Repairing Done'),('Released','Released'))
    status=models.CharField(max_length=50,choices=stat,default='Pending',null=True)

    def __str__(self):
        return self.problem_description

class Attendance(models.Model):
    mechanic=models.ForeignKey('Mechanic',on_delete=models.CASCADE,null=True)
    date=models.DateField()
    present_status = models.CharField(max_length=10)

class Feedback(models.Model):
    date=models.DateField(auto_now=True)
    by=models.CharField(max_length=40)
    message=models.CharField(max_length=500)

class FuelConsumption(models.Model):
    # request = models.ForeignKey(Request, on_delete=models.CASCADE)
    vehicle = models.CharField(max_length=7, default=False, null=False)
    driver = models.CharField(max_length=255, default=False, null=False)
    distance = models.DecimalField(max_digits=10, decimal_places=2)
    fuel_consumed = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    date = models.DateField(auto_now_add=True)
    route = models.CharField(max_length=255)

    accd = (('Yes', 'Yes'), ('No', 'No'))
    accident = models.CharField(max_length=255, null=False, default='No', choices=accd)

    acc_remarks = models.CharField(max_length=500, null=True)

    pl_esc=(('Yes', 'Yes'), ('No', 'No'))
    police_escort = models.CharField(max_length=255, null=False, default=0,choices=pl_esc)

    own_esc = (('Yes', 'Yes'), ('No', 'No'))
    owner_escort = models.CharField(max_length=255, null=False, default=0, choices=own_esc)

    def save(self, *args, **kwargs):
        self.fuel_consumed = (float(self.distance) * 9.4) / 100
        super().save(*args, **kwargs)

    def __str__(self):
        return 'using the ' + self.route + ' the vehicle ' + self.vehicle + ' has consumed ' + str(self.fuel_consumed) + ' gallons of fuel'